# DB HiTek 180 nm: local 1.8 V SVT model subset (HSPICE source)

These files were extracted mechanically from a user-provided `1830BD18BA_Rev3p6p0.l` (Rev 3p6p0) for local, authorized use. The actual model coefficients and binned definitions are copied **unaltered**; no independent calibration or ngspice compatibility conversion has yet been validated.

## What's in each corner file

- `db180_svt018_tt.lib` (and `ff`, `ss`, `fs`, `sf`): the corner parameter definitions, noise parameter flags, all **30 NMOS and 24 PMOS** MOS model bins, their HSPICE device subcircuits, and the `nw_psub` junction diode required for PMOS 5th substrate terminal.
- Original `nch_svt_1p8v` has pins **D G S B**. Original `pch_svt_1p8v` has pins **D G S B SUB**.
- Not included: LDMOS, HV devices, other Vt families, isolated variants, separate mismatch/Monte Carlo models, `eSOA`, or digital Verilog-A body diodes.
- Original HSPICE `.lib` cross-references are replaced by a **flattened single file per corner**.

## Try locally with ngspice

From the folder containing a corner file and the smoke-test netlist:

```bash
ngspice --version
ngspice -b smoke_ngspice_inverter.cir > smoke_ngspice.log 2>&1
```

The hidden `.spiceinit` file sets `ngbehavior=hs`. Inspect `smoke_ngspice.log` for `unknown parameter`, parse failures, model binning errors or convergence warnings. If your version of ngspice does not recognize model parameters such as HSPICE-specific BSIM3 binning flags, a **documented compatibility adapter with numerical HSPICE reference comparison** is needed; simply deleting parameters without testing is not acceptable.

The included SPICE smoke test is **NOT YET executed**. Construction of a file and static integrity checks **do not prove** electrical correctness or physical equivalence to the foundry's validated HSPICE model. Do not compare chip power or eye behavior until an OP/DC/transient benchmark passes.

## Why not extract just two `.model` lines?

The foundry uses 54 geometry bins, `.param` process-corner shifts and a PMOS substrate-well junction diode, as well as wrapper subcircuits. A two-line MOS model cannot preserve this behavior.

## Recreate or change corners

```bash
python extract_svt18.py /secure/path/1830BD18BA_Rev3p6p0.l --out . --corners tt ff ss fs sf
```

The generator is only an authorized local transform. Because the source contains a proprietary license/restriction notice, do **not** commit these derivative `.lib` files or distribute the ZIP to third parties without explicit authorization. Private GitHub is still a third-party host. Code and parameter-free documentation can be stored separately.
