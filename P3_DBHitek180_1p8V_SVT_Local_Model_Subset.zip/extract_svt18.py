#!/usr/bin/env python3
"""Extract the *complete dependent cards* of DB HiTek 1.8-V SVT MOS devices.

Reads a copy of the HSPICE library supplied by the rights holder/user and writes
local, non-public, corner-specific small libraries.  Preserves original MOS
parameters and binning definitions.  This is a structural extraction, NOT a
verified HSPICE-to-ngspice model conversion. Use only when license permits.

Usage: python extract_svt18.py /path/to/1830BD18BA_Rev3p6p0.l --out ./
"""
from __future__ import annotations
import argparse
import re
from pathlib import Path

CORNER_SECTIONS={key:f'{key}_svt018' for key in ('tt','ff','ss','fs','sf')}
LIBS=('noise_svt_1p8v','mos_svt018','nmc_svt018','pmc_svt018')
REQUIRED_MODELS=('nch_svt_1p8v_lvs','pch_svt_1p8v_lvs')


def block(lines: list[str], libname: str) -> list[str]:
    start_re=re.compile(r'^\s*\.lib\s+'+re.escape(libname)+r'\s*$',re.I)
    end_re=re.compile(r'^\s*\.endl\s+'+re.escape(libname)+r'\s*$',re.I)
    start=[i for i,l in enumerate(lines) if start_re.match(l)]
    if len(start)!=1:
        raise RuntimeError(f'Expected exactly one start for {libname}, found {len(start)}')
    end=next((i for i in range(start[0]+1,len(lines)) if end_re.match(lines[i])),None)
    if end is None:raise RuntimeError(f'Missing .endl {libname}')
    return lines[start[0]+1:end]


def extract_diode(lines: list[str], modelname='nw_psub') -> list[str]:
    start_re=re.compile(r'^\s*\.model\s+'+re.escape(modelname)+r'\s+\S+',re.I)
    starts=[i for i,l in enumerate(lines) if start_re.match(l)]
    if len(starts)!=1:raise RuntimeError(f'Missing or duplicate diode {modelname}')
    i=starts[0]; result=[lines[i]]
    for l in lines[i+1:]:
        if l.lstrip().startswith('+'):
            result.append(l)
        elif not l.strip() or l.lstrip().startswith('*'):
            # comments may be interposed in model continuation
            continue
        else:
            break
    return result


def skip_nested_lib_refs(corner_lines: list[str]) -> list[str]:
    # A corner includes several HSPICE recursive .lib references. We only retain
    # the corner parameters; sections explicitly selected below supply devices.
    return [l for l in corner_lines if not re.match(r'^\s*\.lib\s+[.\'\"/\\]',l,re.I)]


def create_corner(source: Path, outdir: Path, corner: str) -> Path:
    lines=source.read_text(encoding='latin-1').splitlines()
    outdir.mkdir(parents=True,exist_ok=True)
    header=[
        f'* Local-only structural subset of {source.name}, process {corner.upper()}, 1.8V SVT',
        '* Models below remain derived from their original foundry source. Do not redistribute.',
        '* Preserves original model cards and 54 width/length bins; no MOS fit was synthesized.',
        '* Not yet electrically validated on ngspice vs HSPICE.',
        '* Subckt pins: nch_svt_1p8v D G S B ; pch_svt_1p8v D G S B SUB.',
        '',
    ]
    c=skip_nested_lib_refs(block(lines,CORNER_SECTIONS[corner]))
    # DO NOT strip .param corner values; model cards reference these in expressions.
    noise=block(lines,LIBS[0]); mos=block(lines,LIBS[1])
    nwrap=block(lines,LIBS[2]); pwrap=block(lines,LIBS[3])
    diode=extract_diode(lines)
    out=header
    for label,section in [
        ('Noise flags (non-statistical)',noise),
        (f'{corner.upper()} corner process and noise parameters',c),
        ('Foundry NMOS/PMOS binned models',mos),
        ('Four-pin NMOS subcircuit',nwrap),
        ('Five-pin PMOS subcircuit',pwrap),
        ('PMOS substrate-well diode (required)',diode),
    ]:
        out.extend(['',f'* --- {label} ---',*section])
    dest=outdir/f'db180_svt018_{corner}.lib'
    dest.write_text('\n'.join(out)+'\n',encoding='latin-1')
    verify_output(dest,corner)
    return dest


def verify_output(dest:Path,corner:str):
    s=dest.read_text(encoding='latin-1'); low=s.lower()
    assert len(re.findall(r'^\s*\.model\s+nch_svt_1p8v_lvs\.\d+',s,re.I|re.M))==30
    assert len(re.findall(r'^\s*\.model\s+pch_svt_1p8v_lvs\.\d+',s,re.I|re.M))==24
    for token in ['.subckt nch_svt_1p8v ','.subckt pch_svt_1p8v ','.model  nw_psub','nsvt018_tox','psvt018_tox']:
        assert token.lower() in low,(dest,token)
    assert '.lib \'./1830bd' not in low
    assert '.hdl ' not in low
    assert 'dbody_nldm' not in low
    print(f'{corner.upper():>2}: {dest.name} | {dest.stat().st_size:,} bytes | 30 NMOS + 24 PMOS bins | diode included')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path)
    p.add_argument('--out',type=Path,default=Path('.'))
    p.add_argument('--corners',nargs='+',choices=list(CORNER_SECTIONS),default=list(CORNER_SECTIONS))
    args=p.parse_args()
    for corner in args.corners:
        create_corner(args.source,args.out,corner)

if __name__=='__main__':main()
